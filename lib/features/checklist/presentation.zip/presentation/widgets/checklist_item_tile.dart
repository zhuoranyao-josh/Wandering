import 'package:flutter/material.dart';

import '../../../../l10n/app_localizations.dart';
import '../../domain/entities/checklist_detail.dart';

class ChecklistItemTile extends StatelessWidget {
  const ChecklistItemTile({
    super.key,
    required this.item,
    required this.onToggleCompleted,
    this.onTap,
  });

  final ChecklistDetailItem item;
  final ValueChanged<bool> onToggleCompleted;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final demoBadge = item.dataSource?.trim() == 'demo_estimated'
        ? t?.checklistDemoEstimateBadge
        : null;
    final estimatedText = _buildEstimatedText();
    final accuracyText = (item.accuracyNote ?? '').trim();
    final hasExternalUrl = (item.externalUrl ?? '').trim().isNotEmpty;

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFFE5E7EB)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Checkbox(
                value: item.isCompleted,
                onChanged: (value) => onToggleCompleted(value ?? false),
                visualDensity: VisualDensity.compact,
                activeColor: const Color(0xFF3B6EEA),
                checkColor: Colors.white,
                side: const BorderSide(color: Color(0xFFC5C8D0), width: 1.2),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            item.title.trim(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: item.isCompleted
                                  ? const Color(0xFF9CA3AF)
                                  : const Color(0xFF111827),
                              decoration: item.isCompleted
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                            ),
                          ),
                        ),
                        if (demoBadge != null) ...<Widget>[
                          const SizedBox(width: 8),
                          _Badge(text: demoBadge),
                        ],
                      ],
                    ),
                    if ((item.subtitle ?? '').trim().isNotEmpty) ...<Widget>[
                      const SizedBox(height: 2),
                      Text(
                        item.subtitle!.trim(),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 15,
                          color: Color(0xFF98A2B3),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                    if (estimatedText.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 4),
                      Text(
                        estimatedText,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 13.5,
                          color: Color(0xFF3B6EEA),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                    if (accuracyText.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 4),
                      Text(
                        accuracyText,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xFF9CA3AF),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  if (hasExternalUrl) ...<Widget>[
                    const Icon(
                      Icons.open_in_new_rounded,
                      color: Color(0xFF98A2B3),
                      size: 18,
                    ),
                    const SizedBox(height: 8),
                  ],
                  const Icon(
                    Icons.chevron_right_rounded,
                    color: Color(0xFFCDD2DB),
                    size: 22,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _buildEstimatedText() {
    final directText = (item.estimatedPriceText ?? '').trim();
    if (directText.isNotEmpty) {
      return directText;
    }
    if (item.estimatedPriceMin != null && item.estimatedPriceMax != null) {
      return '${item.currency ?? ''} ${item.estimatedPriceMin!.round()} - ${item.estimatedPriceMax!.round()}';
    }
    if (item.estimatedCostMin != null && item.estimatedCostMax != null) {
      return '${item.currency ?? ''} ${item.estimatedCostMin!.round()} - ${item.estimatedCostMax!.round()}';
    }
    return '';
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 11,
          color: Color(0xFF475467),
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
